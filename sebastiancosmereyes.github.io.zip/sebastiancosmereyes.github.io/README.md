# sebastiancosmereyes.github.io

Personal aerospace-engineering portfolio for Sebastian Cosme-Reyes, built with plain HTML
and CSS (no build step, no framework). Published with GitHub Pages at:

**https://sebastiancosmereyes.github.io**

---

## Site structure

```
index.html                          Homepage: hero, about, project cards, skills, contact
README.md                           This file
assets/
  css/
    style.css                       Shared stylesheet for every page
  images/
    bell-x1/                        Images for the Bell X-1 case study
    rotating-cylinder/               Images for the rotating cylinder case study
    martian-dust/                   Images for the Martian dust case study
    bipropellant-engine/            Images for the bipropellant engine case study
projects/
  bell-x1.html                      Case study page
  rotating-cylinder.html            Case study page
  martian-dust.html                 Case study page (ongoing research)
  bipropellant-engine.html          Case study page (high-level only — see note in file)
```

Each `assets/images/<project>/` folder currently just holds a placeholder file so the
folder exists in Git (empty folders aren't tracked by Git). Add real images there and
delete the placeholder whenever you like.

---

## 1. Deploying the site (beginner-friendly)

You don't need to install anything locally — you can do all of this through GitHub's
website.

### Step 1: Create the repository
1. Go to [github.com/new](https://github.com/new) while signed in as `sebastiancosmereyes`.
2. Name the repository exactly: `sebastiancosmereyes.github.io`
   (this exact name is what makes GitHub Pages serve it at the root domain).
3. Set it to **Public**.
4. Don't add a README, .gitignore, or license in this step — you'll upload your own files.
5. Click **Create repository**.

### Step 2: Upload the files
1. On your new (empty) repository page, click **uploading an existing file**.
2. Drag in this whole folder structure — GitHub's uploader supports dragging folders,
   which will preserve the `assets/` and `projects/` subfolders.
3. Scroll down, add a commit message like "Initial site", and click **Commit changes**.
4. If the uploader has trouble with nested folders, upload `index.html`, `README.md`, and
   `style.css` first, then use **Add file → Create new file** and type a path like
   `projects/bell-x1.html` to create each remaining file with the matching content pasted in.

### Step 3: Turn on GitHub Pages
1. In your repository, go to **Settings → Pages**.
2. Under **Build and deployment → Source**, choose **Deploy from a branch**.
3. Under **Branch**, choose `main` (or `master`, whichever your repo uses) and folder `/ (root)`.
4. Click **Save**.
5. Wait a minute or two, then visit **https://sebastiancosmereyes.github.io** — your site
   should be live. GitHub Pages rebuilds automatically every time you commit changes.

### Step 4 (optional): Edit directly in the browser afterward
Once the repo exists, you don't need to re-upload everything for small changes. Open any
file in GitHub, click the pencil ("Edit this file") icon, make your change, and commit
directly to `main`. The live site updates automatically within a minute or two.

---

## 2. Adding a new project later

To add a fifth project (or beyond):

1. **Duplicate a project page.** In `projects/`, open the case study closest to your new
   project (e.g. `rotating-cylinder.html`), copy its content, and create a new file such as
   `projects/your-project.html` with that content pasted in.
2. **Edit the new page:** update the `<title>`, the hero heading, status badge, "case facts,"
   and each section (objective, context, role, approach, results, limitations, video, code
   link) to match your new project. Every section has an HTML comment marking what to replace.
3. **Create an image folder:** add `assets/images/your-project/` and upload your images there.
4. **Add a project card to the homepage:** in `index.html`, find the comment that says
   `TO ADD A NEW PROJECT CARD` inside the `<div class="project-grid">` section, duplicate one
   of the existing `<a class="project-card">` blocks, and point it at your new page.
5. **Update the "next project" links** at the bottom of neighboring case study pages if you
   want the project-to-project navigation to include your new page.
6. **Commit your changes** (either through the browser editor or by re-uploading the files).

## 3. Adding an image to an existing project

1. Upload your image file into the matching folder, e.g. `assets/images/bell-x1/plot1.jpg`.
2. Open the relevant HTML file and find the `<div class="media-frame">` placeholder you want
   to replace, or the commented-out `<img>` line just above/below it.
3. Replace the placeholder `<div>` with an `<img>` tag, for example:
   ```html
   <img src="../assets/images/bell-x1/plot1.jpg" alt="Describe exactly what the image shows">
   ```
4. Always write real, descriptive `alt` text — screen readers and search engines rely on it,
   and "image" or "plot" alone isn't descriptive enough.
5. On the homepage, the same idea applies to `<div class="project-card-media is-placeholder">`
   — replace it with an `<img>` inside the `<div class="project-card-media">` (remove the
   `is-placeholder` class and the `data-placeholder-label` attribute once you add a real image).

## 4. Adding a video (YouTube or Vimeo)

Videos are embedded rather than uploaded directly to GitHub, since GitHub isn't built for
hosting long video files.

1. Upload your video to YouTube or Vimeo (unlisted is fine if you don't want it publicly
   searchable — it will still play when embedded).
2. Get the **embed URL**:
   - YouTube: `https://www.youtube.com/embed/VIDEO_ID`
   - Vimeo: `https://player.vimeo.com/video/VIDEO_ID`
3. In the relevant project page, find the `<div class="video-frame is-placeholder">` block
   and replace it with:
   ```html
   <div class="video-frame">
     <iframe src="https://www.youtube.com/embed/VIDEO_ID"
             title="Describe the video"
             allowfullscreen></iframe>
   </div>
   ```

---

## 5. Final review checklist

Before (or after) publishing, check:

**Professionalism & accuracy**
- [ ] Every technical claim matches your résumé or verified project notes — nothing invented
- [ ] Team-based work is described as team-based, with your specific contribution called out
- [ ] The bipropellant engine page still only contains information you're cleared to share
- [ ] The Martian dust page is clearly labeled as ongoing research, with no implied results

**Privacy**
- [ ] No personal phone number or personal email appears anywhere in the published site
- [ ] The Contact section only links to things you've explicitly approved (GitHub, LinkedIn, etc.)

**Accessibility**
- [ ] Every real image has specific, descriptive `alt` text (not "image" or "photo")
- [ ] You can reach every link and button using only the Tab key, with a visible focus outline
- [ ] Page titles and headings make sense if read out of context by a screen reader

**Mobile & responsiveness**
- [ ] Homepage and at least one case study page look correct on a phone-width browser window
- [ ] The mobile menu (hamburger button) opens and closes correctly on a narrow screen
- [ ] No text or images overflow the screen edge on mobile

**Media**
- [ ] Placeholder blocks are either replaced with real media or clearly still marked as
      placeholders (not left looking like a broken final result)
- [ ] Video embeds use YouTube/Vimeo — no large video files committed to the repository

**Links**
- [ ] Every "add link" placeholder (GitHub repo links, LinkedIn, contact) is either filled
      in or intentionally left as a placeholder you're aware of
